﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication9
{
    public partial class Form1 : Form
    {   
        public Form1()
        {
            InitializeComponent();
        }
        char [,] arr =new char[3,3];
           

        bool y1 = true, y2 = true, y3 = true, y4 = true, y5 = true, y6 = true, y7 = true, y8 = true, y9 = true;
        int x = 0, c = 0;
        private void replace()
        {
          
            button1.Text = "";
            button2.Text = "";
            button3.Text = "";
            button4.Text = "";
            button5.Text = "";
            button6.Text = "";
            button7.Text = "";
            button8.Text = "";
            button9.Text = "";
            y1 = true;
            y2 = true;
            y3 = true;
            y4 = true;
            y5 = true;
            y6 = true;
            y7 = true;
            y8 = true;
            y9 = true;
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    arr[i, j] = '0';
                }
            }
                c = 0;
            x = 0;    
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        private void check()
        {

            //if ((button1.Text == button2.Text) && (button2.Text == button3.Text) && button3.Text!="")
            //   {
            //       if (button1.Text == "X")
            //       {
            //           MessageBox.Show("X Win");
            //       }
            //       else if (button1.Text == "O" )
            //       {
            //           MessageBox.Show("O Win");
            //       }
            //       replace();
            //   }
            //else if ((button4.Text == button5.Text) && (button5.Text == button6.Text) && button4.Text != "")
            //   {
            //       if (button4.Text == "X" )
            //       {
            //           MessageBox.Show("X Win");
            //       }
            //       else if (button4.Text == "O" )
            //       {
            //           MessageBox.Show("O Win");
            //       }
            //       replace();
            //   }
            //else if ((button7.Text == button8.Text) && (button8.Text == button9.Text) && button7.Text != "")
            //   {
            //       if (button7.Text == "X" )
            //       {
            //           MessageBox.Show("X Win");
            //       }
            //       else if (button7.Text == "O" )
            //       {
            //           MessageBox.Show("O Win");
            //       }
            //       replace();
            //   }
            //else if ((button1.Text == button4.Text) && (button4.Text == button7.Text) && button4.Text != "")
            //   {
            //       if (button1.Text == "X" )
            //       {
            //           MessageBox.Show("X Win");
            //       }
            //       else if (button1.Text == "O")
            //       {
            //           MessageBox.Show("O Win");
            //       }
            //       replace();
            //   }
            //else if ((button2.Text == button5.Text) && (button5.Text == button8.Text) && button8.Text != "")
            //   {
            //       if (button2.Text == "X" )
            //       {
            //           MessageBox.Show("X Win");
            //       }
            //       else if (button2.Text == "O" )
            //       {
            //           MessageBox.Show("O Win");
            //       }
            //       replace();
            //   }
            //else if ((button3.Text == button6.Text) && (button6.Text == button9.Text) && button9.Text != "")
            //   {
            //       if (button3.Text == "X")
            //       {
            //           MessageBox.Show("X Win");
            //       }
            //       else if (button3.Text == "O")
            //       {
            //           MessageBox.Show("O Win");
            //       }
            //       replace();
            //   }
            //else if ((button3.Text == button5.Text) && (button5.Text == button7.Text) && button7.Text != "")
            //   {
            //       if (button3.Text == "X")
            //       {
            //           MessageBox.Show("X Win");
            //       }
            //       else if (button3.Text == "O")
            //       {
            //           MessageBox.Show("O Win");
            //       }
            //       replace();
            //   }
            //else if ((button1.Text == button5.Text) && (button5.Text == button9.Text) && button1.Text != "")
            //   {
            //       if (button1.Text == "X")
            //       {
            //           MessageBox.Show("X Win");
            //       }
            //       else if (button1.Text == "O")
            //       {
            //           MessageBox.Show("O Win");
            //       }
            //       replace();
            //   }
            //else if(c==9)
            //   {
            //       MessageBox.Show("Tied");
            //       replace();
            //   }
            /////////////////////////////////////Horizontal/////////////////////
            for (int i = 0; i < 3; i++)
            {
                bool a = true;
                char b='0';
                for (int j = 0; j < 3; j++)
                {
                    if (j == 0) b = arr[i, j];
                    else
                    {
                        if (arr[i, j] != b||arr[i,j]=='0')
                        {
                            a = false; break;
                        }
                    }
                }
                if (a) { MessageBox.Show(b + "wins!"); replace(); break; }
            }

            /////////////////////////////////////////////////////Vertical////////////////

            for (int j = 0; j < 3; j++)
            {
                bool a = true;
                char b = '0';
                for (int i = 0; i < 3; i++)
                {
                    if (i== 0) b = arr[i, j];
                    else
                    {
                        if (arr[i, j] != b || arr[i, j] == '0')
                        {
                            a = false; break;
                        }
                    }
                }
                if (a) { MessageBox.Show(b + "wins!"); replace(); break; }
            }
        //////////////////////////////////////////////Left Diagonal///////////////////////
            char c = arr[0, 0];
            bool f=true;
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if (i == j)
                    {
                        if (arr[i, j] != c || arr[i, j] == '0') { f = false; break; }
                    }
                }
            }
            if (f)
            {
                MessageBox.Show(c + "wins!");
                replace();
            }
            /////////////////////////////////////////////RightDaiognal//////////////////////////////////////
            char d = arr[0, 2];
            bool s = true;
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if ((i+j)==2)
                    {
                        if (arr[i, j] != d || arr[i, j] == '0') { s = false; break; }
                    }
                }
            }
            if (s)
            {
                MessageBox.Show(c + "wins!");
                replace();
            }
            
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (y1)
            {
                if (x % 2 == 0)
                {
                    button1.Text = "X"; 
                    arr[0,0] = 'x';
                }
                else if (x % 2 != 0)
                {
                    button1.Text = "O";
                    arr[0,0] = 'o';
                }
                x++;
                y1 = false;
                c++;
                if (c >= 5&& c<=9)
                    check();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (y2)
            {
                if (x % 2 == 0)
                {
                    button2.Text = "X";
                    arr[0,1] = 'x';
                }


                else if (x % 2 != 0)
                {
                    button2.Text = "O";
                    arr[0,1] = 'o';
                }
                x++;
                y2 = false;
                c++;
                if (c >= 5 && c <= 9)
                    check();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (y3)
            {
                if (x % 2 == 0)
                {
                    button3.Text = "X";
                    arr[0,2] = 'x';
                    
                }


                else if (x % 2 != 0)
                {
                    button3.Text = "O";
                    arr[0,2] = 'o';
                }
                x++;
                y3 = false;
                
                
                
                c++;
                if (c >= 5 && c <= 9)
                check();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (y4)
            {
                if (x % 2 == 0)
                {
                    button4.Text = "X";
                    arr[1,0] = 'x';
                }


                else if (x % 2 != 0)
                {
                    button4.Text = "O";
                    arr[1,0] = 'o';
                }
                x++;
                y4 = false;
               
               
                
                c++;
                if (c >= 5 && c <= 9)
                check();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (y5)
            {
                if (x % 2 == 0)
                {
                    button5.Text = "X";
                    arr[1, 1] = 'x';
                }


                else if (x % 2 != 0)
                {
                    button5.Text = "O";
                    arr[1, 1] = 'o';
                }
                x++;
                y5 = false;
                
                c++;
                if (c >= 5 && c <= 9)
                check();
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (y6)
            {
                if (x % 2 == 0)
                {
                    button6.Text = "X";
                    arr[1, 2] = 'x';
                }


                else if (x % 2 != 0)
                {
                    button6.Text = "O";
                    arr[1, 2] = 'o';
                }
                x++;
                y6 = false;
               
                
                
                c++;
                if (c >= 5 && c <= 9)
                check();
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (y7)
            {
                if (x % 2 == 0)
                {
                    button7.Text = "X";
                    arr[2, 0] = 'x';
                }


                else if (x % 2 != 0)
                {
                    button7.Text = "O";
                    arr[2, 0] = 'o';
                }
                x++;
                y7 = false;
               
               
                   c++;
                if (c >= 5 && c <= 9)
                check();
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {


            if (y8)
            {
                if (x % 2 == 0)
                {
                    button8.Text = "X";
                    arr[2, 1] = 'x';
                }


                else if (x % 2 != 0)
                {
                    button8.Text = "O";
                    arr[2, 1] = 'o';
                }
                x++;
                y8 = false;
                
            
                c++;
                if (c >= 5 && c <= 9)
                check();
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (y9)
            {
                if (x % 2 == 0)
                {
                    button9.Text = "X";
                    arr[2, 2] = 'x';
                }
                else if (x % 2 != 0)
                {
                    button9.Text = "O";
                    arr[2, 2] = 'o';
                }
                x++;
                y9 = false;
                c++;
                if (c >= 5 && c <= 9)
                check();
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            
        }
    }
}